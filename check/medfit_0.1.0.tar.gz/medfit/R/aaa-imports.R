#' @import S7
#' @import methods
#' @import checkmate
#' @importFrom stats glm lm coef vcov sigma nobs formula gaussian
NULL
